package com.example.djmayfielditunesapp.views

import android.media.AudioAttributes
import android.media.MediaPlayer
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.example.djmayfielditunesapp.data.MusicInfo
import com.example.djmayfielditunesapp.databinding.MusicListItemBinding

class MusicAdapter(
    private val  list: List<MusicInfo>,
): RecyclerView.Adapter<MusicAdapter.MusicInfoViewHolder>() {

    inner class MusicInfoViewHolder(private val binding: MusicListItemBinding): RecyclerView.ViewHolder(binding.root){
        fun onBind(musicInfo: MusicInfo){

            binding.tvCollectionName.text = musicInfo.collectionName
            binding.tvArtistName.text = musicInfo.artistName
            binding.tvTrackPrice.text = musicInfo.trackPrice.toString()

            

            Glide.with(binding.ivArtwork)
                .load(musicInfo.artworkUrl60)
                .into(binding.ivArtwork)

        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MusicInfoViewHolder {
        return MusicInfoViewHolder(
            MusicListItemBinding.inflate(
                LayoutInflater.from(parent.context),
                parent,
                false
            )
        )
    }

    override fun onBindViewHolder(holder: MusicInfoViewHolder, position: Int) {
        holder.onBind(list[position])
    }

    override fun getItemCount(): Int {
        return list.size
    }

}