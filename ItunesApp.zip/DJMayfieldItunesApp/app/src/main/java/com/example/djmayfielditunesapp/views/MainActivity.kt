package com.example.djmayfielditunesapp.views

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.djmayfielditunesapp.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    // findViewById
//    lateinit var tvHelloWorld: TextView
//    lateinit var tvJeffery: TextView
//    lateinit var btn: Button

    // ViewBinding
    lateinit var binding: ActivityMainBinding // -> null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityMainBinding.inflate(layoutInflater)
        // R.layout.activity_main
        setContentView(binding.root)
//        supportFragmentManager

    }
}